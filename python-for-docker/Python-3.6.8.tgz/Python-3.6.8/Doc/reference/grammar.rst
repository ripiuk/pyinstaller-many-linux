Full Grammar specification
==========================

This is the full Python grammar, as it is read by the parser generator and used
to parse Python source files:

.. literalinclude:: ../../Grammar/Grammar
